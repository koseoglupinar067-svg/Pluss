package com.retrivedmods.wclient.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.provider.Settings
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.retrivedmods.wclient.game.KeybindManager

/**
 * Receives hardware keys without taking focus away from Minecraft. Returning false
 * lets the original key continue to Minecraft. Keybinds are ignored while an
 * editable chat/input node is focused.
 */
class KitenaKeybindAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        serviceInfo = serviceInfo.apply {
            flags = flags or AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS
            flags = flags or AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                AccessibilityEvent.TYPE_VIEW_FOCUSED
            packageNames = arrayOf("com.mojang.minecraftpe")
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            notificationTimeout = 50
        }
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (!isMinecraftForeground()) return false
        if (isTypingInChat()) return false
        KeybindManager.handleKeyEvent(event)
        // Do not consume the key: Minecraft still receives normal movement/action input.
        return false
    }

    private fun isMinecraftForeground(): Boolean {
        val root = rootInActiveWindow ?: return false
        return root.packageName?.toString() == "com.mojang.minecraftpe"
    }

    private fun isTypingInChat(): Boolean {
        val root = rootInActiveWindow ?: return false
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        return focused?.isEditable == true
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit
}
