package com.retrivedmods.wclient.game.module.motion

import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket

/**
 * Client-side Timer.
 *
 * It adjusts the tick value carried by PlayerAuthInput packets using a
 * configurable multiplier. 1.0x leaves the packet timing unchanged.
 */
class TimerModule : Module("Timer", ModuleCategory.Motion) {

    private var speed by floatValue("Speed", 1.0f, 0.5f..3.0f)

    private var virtualTick = 0.0
    private var initialized = false

    override fun onEnabled() {
        initialized = false
        super.onEnabled()
    }

    override fun onDisabled() {
        initialized = false
        super.onDisabled()
    }

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        if (!isEnabled) return

        val packet = interceptablePacket.packet as? PlayerAuthInputPacket ?: return

        if (!initialized) {
            virtualTick = packet.tick.toDouble()
            initialized = true
            return
        }

        virtualTick += speed.toDouble()

        // Keep the value monotonic even if a server sends a newer tick.
        val incoming = packet.tick.toDouble()
        if (incoming > virtualTick && speed >= 1.0f) {
            virtualTick = incoming
        }

        packet.tick = virtualTick.toLong()
    }
}
