package com.retrivedmods.wclient.game.module.combat

import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket

/**
 * Bed Aura module shell for the KitenaTR module system.
 *
 * The Bedrock protocol requires server/version-specific block interaction data
 * for reliable bed placement/explosion. This module therefore only runs its
 * tick hook when enabled and does not send fabricated placement packets.
 */
class BedAuraModule : Module("Bed Aura", ModuleCategory.Combat) {
    private val range by floatValue("Range", 5.0f, 1f..8f)
    private val delay by intValue("Delay", 2, 1..20)

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        if (!isEnabled) return
        val packet = interceptablePacket.packet as? PlayerAuthInputPacket ?: return
        if (packet.tick % delay.toLong() != 0L) return

        // Intentionally no synthetic block-use packet here. The module is
        // registered and configurable without risking invalid Bedrock packets.
        @Suppress("UNUSED_VARIABLE")
        val configuredRange = range
    }
}
