package com.retrivedmods.wclient.game.module.combat

import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory
import com.retrivedmods.wclient.game.entity.Entity
import com.retrivedmods.wclient.game.entity.EntityUnknown
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket

/**
 * Crystal Aura for the KitenaTR module system.
 *
 * This implementation handles crystal targeting/attacking using the existing
 * LocalPlayer attack pipeline. It intentionally does not fabricate placement
 * packets because placement packet semantics are server/version dependent.
 */
class CrystalAuraModule : Module("crystal_aura", ModuleCategory.Combat) {

    private var range by floatValue("range", 6.0f, 2f..10f)
    private var delayTicks by intValue("delay", 2, 1..20)
    private var attacksPerCycle by intValue("attacks", 1, 1..5)
    private var nearestFirst by boolValue("nearest", true)

    private var lastAttack = 0L

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        if (!isEnabled) return
        val packet = interceptablePacket.packet as? PlayerAuthInputPacket ?: return

        if (packet.tick % delayTicks.toLong() != 0L) return

        val now = System.currentTimeMillis()
        val minDelay = 1000L / 20L
        if (now - lastAttack < minDelay) return

        val crystals = findCrystals()
        if (crystals.isEmpty()) return

        var attacked = 0
        for (crystal in crystals) {
            if (attacked >= attacksPerCycle) break
            session.localPlayer.attack(crystal)
            attacked++
        }

        if (attacked > 0) lastAttack = now
    }

    private fun findCrystals(): List<Entity> {
        val player = session.localPlayer
        val result = session.level.entityMap.values
            .asSequence()
            .filterIsInstance<EntityUnknown>()
            .filter { it.identifier == "minecraft:end_crystal" }
            .filter { it.distance(player) <= range }
            .toList()

        return if (nearestFirst) {
            result.sortedBy { it.distance(player) }
        } else {
            result
        }
    }
}
