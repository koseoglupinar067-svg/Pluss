package com.retrivedmods.wclient.game.module.misc

import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.cloudburstmc.protocol.bedrock.packet.TextPacket

/**
 * WClient-native chat spammer.
 * Uses the existing GameSession packet path instead of Rubidium-only APIs.
 */
class ChatSpammerModule : Module("Chat Spammer", ModuleCategory.Misc) {
    private val message by stringValue("Message", "KitenaDev", listOf())
    private val delayMs by intValue("Delay", 1000, 100..10000)
    private val prefix by stringValue("Prefix", "", listOf())

    private var job: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main)

    override fun onEnabled() {
        super.onEnabled()
        job?.cancel()
        job = scope.launch {
            while (isActive && isEnabled && isSessionCreated) {
                runCatching {
                    val packet = TextPacket().apply {
                        type = TextPacket.Type.CHAT
                        sourceName = ""
                        this.message = prefix + message
                        xuid = ""
                        platformChatId = ""
                        needsTranslation = false
                    }
                    session.serverBound(packet)
                }
                delay(delayMs.toLong())
            }
        }
    }

    override fun onDisabled() {
        job?.cancel()
        job = null
        super.onDisabled()
    }

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) = Unit
}
