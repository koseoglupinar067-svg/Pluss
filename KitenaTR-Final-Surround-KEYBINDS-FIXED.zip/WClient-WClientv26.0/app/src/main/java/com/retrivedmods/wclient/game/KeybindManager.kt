package com.retrivedmods.wclient.game

import android.view.KeyEvent
import com.retrivedmods.wclient.service.Services

/**
 * Global hardware-key dispatcher. A key can be assigned to any number of modules;
 * every module using the pressed key is toggled together.
 */
object KeybindManager {

    fun handleKeyEvent(event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN || event.repeatCount != 0) return false
        if (!Services.isActive) return false

        val code = event.keyCode
        if (code == KeyEvent.KEYCODE_UNKNOWN || code == 0) return false

        var toggled = false
        ModuleManager.modules
            .filter { it.keybind == code && it.isSessionCreated && !it.private }
            .forEach {
                it.isEnabled = !it.isEnabled
                toggled = true
            }
        return toggled
    }

    fun keyName(keyCode: Int): String {
        if (keyCode == 0) return "NONE"
        return try {
            KeyEvent.keyCodeToString(keyCode)
                .removePrefix("KEYCODE_")
                .replace('_', ' ')
        } catch (_: Throwable) {
            "KEY $keyCode"
        }
    }
}
